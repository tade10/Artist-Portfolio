	   

	  <div class="container-fluid" style="margin-top: 20%;background-color: #222;">
	    <div class="row">
	      <div class="col-md-12" style="padding-top: 20px;padding-bottom: 20px;">
	        <p class="text-center">© The University of Texas at Dallas </p>
	      </div>
	    </div>
	  </div>

</body>
</html>